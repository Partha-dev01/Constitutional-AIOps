# Combined Benchmark Results

> Generated: 2026-05-13 10:16:42 UTC

## constitutional_aiops

| Metric | Value |
|--------|-------|
| Model Type | hybrid |
| Fast Model | qwen3:4b-instruct |
| Reasoning Model | qwen3:14b |
| Annotation Accuracy | 0.0% (0/0) |
| RCA Accuracy | 100.0% (33/33) |
| Overall Accuracy | 100.0% (33/33) |
| BERTScore F1 | 0.0000 |
| Cosine Similarity | 0.0000 |
| Term Overlap | 0.5468 |
| P50 Latency | 30453ms |
| P95 Latency | 80565ms |
| Timestamp | 2026-05-13T10:16:42.753081 |

