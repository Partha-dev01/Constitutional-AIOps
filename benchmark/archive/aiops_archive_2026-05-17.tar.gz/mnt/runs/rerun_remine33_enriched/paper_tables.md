# Constitutional AIOps - Paper Tables

> Generated: 2026-05-13 10:16:42 UTC
> Model: constitutional_aiops
> Source: `benchmark/results/constitutional_aiops/results.json`

## Table 1: Comprehensive Benchmark Results

| Task | Agent | N | Accuracy | BERT-F1 | Cos Sim | Term Overlap | P50 (ms) | P95 (ms) |
|------|-------|---|----------|---------|---------|--------------|----------|----------|
| Annotation | qwen3:4b-instruct | 0 | 0.0% | 0.000 | 0.000 | 0.000 | 0 | 0 |
| RCA | qwen3:14b | 33 | 100.0% | 0.000 | 0.000 | 0.547 | 30453 | 80565 |
| **Overall** | **Hybrid** | **33** | **100.0%** | **0.000** | **0.000** | **0.547** | **30453** | **80565** |


## Table 2: Per-Source Breakdown

| Task | Source | N | Accuracy | BERT-F1 | Cos Sim |
|------|--------|---|----------|---------|--------|
| Rca | Opseval Remine Mobile Communication Network | 1 | 100.0% | 0.000 | 0.000 |
| Rca | Opseval Remine Wired Network | 32 | 100.0% | 0.000 | 0.000 |


## Table 3: Error Analysis

| Failure Mode | Count | Description |
|-------------|-------|-------------|
| **Total Failures** | **0** | **0/33 = 0.0% error rate** |


---

*All values from actual benchmark runs. No fabricated or estimated data.*
