# Combined Benchmark Results

> Generated: 2026-05-17 01:16:58 UTC

## constitutional_aiops

| Metric | Value |
|--------|-------|
| Model Type | hybrid |
| Fast Model | qwen3:4b-instruct |
| Reasoning Model | qwen3:14b |
| Annotation Accuracy | 82.6% (180/218) |
| RCA Accuracy | 92.5% (197/213) |
| Overall Accuracy | 87.5% (377/431) |
| BERTScore F1 | 0.0000 |
| Cosine Similarity | 0.3265 |
| Term Overlap | 0.5249 |
| P50 Latency | 4147ms |
| P95 Latency | 48368ms |
| Timestamp | 2026-05-16T07:39:25.374034 |

